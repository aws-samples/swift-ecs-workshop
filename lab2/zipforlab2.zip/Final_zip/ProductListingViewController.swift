//
//  ProductListingViewController.swift
//  MySampleApp
//
//  Created by Dabhade, Nikhil on 10/18/16.
//
//

import UIKit
import Foundation

class ProductListingViewController: UIViewController, NSURLConnectionDelegate {

    @IBOutlet weak var productImageView: UIImageView!

    @IBOutlet weak var productWebView: UIWebView!
    @IBOutlet weak var productJson: UITextView!
    @IBOutlet weak var productCode: UILabel!
    @IBOutlet weak var code: UILabel!
    @IBOutlet weak var productDescription: UITextView!
    @IBOutlet weak var productName: UITextView!
    @IBOutlet weak var productPrice: UITextView!
    
    override func viewDidLoad() {

        super.viewDidLoad();
      
        let url = URL(string:"http://54.147.8.176/products")
        let data = NSData(contentsOf: url!)
        if data != nil {
            print("-------------------")
            print(String(data:data! as Data, encoding:String.Encoding.utf8))
            print("-------------------")
            
            do {
                //let json = try JSONSerialization.jsonObject(with: data! as Data, options: []) as! NSArray
                let json = try JSONSerialization.jsonObject(with: data! as Data, options: []) as? NSArray
                
                if let first = json?.firstObject {
                    
                    if let jsonName = (first as AnyObject)["name"] as? String {
                        print(jsonName)
                        productName.text = jsonName;
                    }
                    
                    if let jsonURL = (first as AnyObject)["image_url_1"] as? String {
                        print(jsonURL)
                        //var jsoURL = "http://media.performancebike.com/images/performance/products/product-hi/31-5335-BLK-EXTRA.JPG?resize=1500px:1500px&output-quality=100"
                        loadImageFromUrl(url: jsonURL, view: productImageView)
                    }
                    
                    if let jsonDescription = (first as AnyObject)["description"] as? String {
                        print(jsonDescription)
                        productDescription.text = jsonDescription;
                    }
                    
                    if let jsonPrice = (first as AnyObject)["price"] as? Double {
                        print(jsonPrice)
                        productPrice.text = "Price: " + String(jsonPrice)
                    }
                    
                }
                
            } catch let specialErr as NSError {
                print("error serializing JSON: \(specialErr)")
            }
            
            productJson.text = String(data:data! as Data, encoding:String.Encoding.utf8);
        }

        
        
   /*
        
        sample json 
        
        [
            {
                "count":5,
                "description":"This is a testproduct",
                "id":1,
                "image_url_1":"http:\/\/amazon.com",
                "image_url_2":"http:\/\/amazon.com",
                "name":"testproduct",
                "price":20.5,
                "url":"http:\/\/54.147.8.176\/products\/1"
            }
        ]
 
*/
        
    }
    
    func loadImageFromUrl(url: String, view: UIImageView){
        
        // Create Url from string
        let url = NSURL(string: url)!
        let task = URLSession.shared.dataTask(with: url as URL) { (responseData, responseUrl, error) -> Void in
            if let data = responseData{
                // execute in UI thread
                DispatchQueue.main.async(execute: { () -> Void in
                    view.image = UIImage(data: data)
                })
            }
        }
        
        // Run task
        task.resume()
    }
    

}
